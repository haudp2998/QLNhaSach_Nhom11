﻿namespace QLNhaSach
{
    partial class frmChuongtrinh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmChuongtrinh));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gIAODIỆNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dANHMỤCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sÁCHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kHÁCHHÀNGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nGHIỆPVỤToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nHẬPSÁCHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hÓAĐƠNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tHUTIỀNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tHỐNGKÊBÁOCÁOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bÁOCÁOTỒNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bÁOCÁONỢToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cHỨCNĂNGADMINToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tHAYĐỔIQUYĐỊNHToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.qUẢNLÝNHÂNVIÊNToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.qUẢNLÝToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đỔIMẬTKHẨUToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.đĂNGXUẤTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tHOÁTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gIAODIỆNToolStripMenuItem,
            this.dANHMỤCToolStripMenuItem,
            this.nGHIỆPVỤToolStripMenuItem,
            this.tHỐNGKÊBÁOCÁOToolStripMenuItem,
            this.cHỨCNĂNGADMINToolStripMenuItem,
            this.qUẢNLÝToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(831, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gIAODIỆNToolStripMenuItem
            // 
            this.gIAODIỆNToolStripMenuItem.Name = "gIAODIỆNToolStripMenuItem";
            this.gIAODIỆNToolStripMenuItem.Size = new System.Drawing.Size(76, 20);
            this.gIAODIỆNToolStripMenuItem.Text = "GIAO DIỆN";
            // 
            // dANHMỤCToolStripMenuItem
            // 
            this.dANHMỤCToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sÁCHToolStripMenuItem,
            this.kHÁCHHÀNGToolStripMenuItem});
            this.dANHMỤCToolStripMenuItem.Name = "dANHMỤCToolStripMenuItem";
            this.dANHMỤCToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.dANHMỤCToolStripMenuItem.Text = "DANH MỤC";
            // 
            // sÁCHToolStripMenuItem
            // 
            this.sÁCHToolStripMenuItem.Name = "sÁCHToolStripMenuItem";
            this.sÁCHToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.sÁCHToolStripMenuItem.Text = "TRA CỨU SÁCH";
            this.sÁCHToolStripMenuItem.Click += new System.EventHandler(this.sÁCHToolStripMenuItem_Click);
            // 
            // kHÁCHHÀNGToolStripMenuItem
            // 
            this.kHÁCHHÀNGToolStripMenuItem.Name = "kHÁCHHÀNGToolStripMenuItem";
            this.kHÁCHHÀNGToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.kHÁCHHÀNGToolStripMenuItem.Text = "KHÁCH HÀNG";
            this.kHÁCHHÀNGToolStripMenuItem.Click += new System.EventHandler(this.kHÁCHHÀNGToolStripMenuItem_Click);
            // 
            // nGHIỆPVỤToolStripMenuItem
            // 
            this.nGHIỆPVỤToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nHẬPSÁCHToolStripMenuItem,
            this.hÓAĐƠNToolStripMenuItem,
            this.tHUTIỀNToolStripMenuItem});
            this.nGHIỆPVỤToolStripMenuItem.Name = "nGHIỆPVỤToolStripMenuItem";
            this.nGHIỆPVỤToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.nGHIỆPVỤToolStripMenuItem.Text = "NGHIỆP VỤ";
            // 
            // nHẬPSÁCHToolStripMenuItem
            // 
            this.nHẬPSÁCHToolStripMenuItem.Name = "nHẬPSÁCHToolStripMenuItem";
            this.nHẬPSÁCHToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.nHẬPSÁCHToolStripMenuItem.Text = "LẬP PHIẾU NHẬP SÁCH";
            this.nHẬPSÁCHToolStripMenuItem.Click += new System.EventHandler(this.nHẬPSÁCHToolStripMenuItem_Click);
            // 
            // hÓAĐƠNToolStripMenuItem
            // 
            this.hÓAĐƠNToolStripMenuItem.Name = "hÓAĐƠNToolStripMenuItem";
            this.hÓAĐƠNToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.hÓAĐƠNToolStripMenuItem.Text = "LẬP HÓA ĐƠN";
            this.hÓAĐƠNToolStripMenuItem.Click += new System.EventHandler(this.hÓAĐƠNToolStripMenuItem_Click);
            // 
            // tHUTIỀNToolStripMenuItem
            // 
            this.tHUTIỀNToolStripMenuItem.Name = "tHUTIỀNToolStripMenuItem";
            this.tHUTIỀNToolStripMenuItem.Size = new System.Drawing.Size(201, 22);
            this.tHUTIỀNToolStripMenuItem.Text = "LẬP PHIẾU THU TIỀN";
            this.tHUTIỀNToolStripMenuItem.Click += new System.EventHandler(this.tHUTIỀNToolStripMenuItem_Click);
            // 
            // tHỐNGKÊBÁOCÁOToolStripMenuItem
            // 
            this.tHỐNGKÊBÁOCÁOToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bÁOCÁOTỒNToolStripMenuItem,
            this.bÁOCÁONỢToolStripMenuItem});
            this.tHỐNGKÊBÁOCÁOToolStripMenuItem.Name = "tHỐNGKÊBÁOCÁOToolStripMenuItem";
            this.tHỐNGKÊBÁOCÁOToolStripMenuItem.Size = new System.Drawing.Size(134, 20);
            this.tHỐNGKÊBÁOCÁOToolStripMenuItem.Text = "THỐNG KÊ-BÁO CÁO";
            // 
            // bÁOCÁOTỒNToolStripMenuItem
            // 
            this.bÁOCÁOTỒNToolStripMenuItem.Name = "bÁOCÁOTỒNToolStripMenuItem";
            this.bÁOCÁOTỒNToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.bÁOCÁOTỒNToolStripMenuItem.Text = "BÁO CÁO TỒN";
            this.bÁOCÁOTỒNToolStripMenuItem.Click += new System.EventHandler(this.bÁOCÁOTỒNToolStripMenuItem_Click);
            // 
            // bÁOCÁONỢToolStripMenuItem
            // 
            this.bÁOCÁONỢToolStripMenuItem.Name = "bÁOCÁONỢToolStripMenuItem";
            this.bÁOCÁONỢToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.bÁOCÁONỢToolStripMenuItem.Text = "BÁO CÁO NỢ";
            this.bÁOCÁONỢToolStripMenuItem.Click += new System.EventHandler(this.bÁOCÁONỢToolStripMenuItem_Click);
            // 
            // cHỨCNĂNGADMINToolStripMenuItem
            // 
            this.cHỨCNĂNGADMINToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tHAYĐỔIQUYĐỊNHToolStripMenuItem,
            this.qUẢNLÝNHÂNVIÊNToolStripMenuItem});
            this.cHỨCNĂNGADMINToolStripMenuItem.Name = "cHỨCNĂNGADMINToolStripMenuItem";
            this.cHỨCNĂNGADMINToolStripMenuItem.Size = new System.Drawing.Size(131, 20);
            this.cHỨCNĂNGADMINToolStripMenuItem.Text = "CHỨC NĂNG ADMIN";
            // 
            // tHAYĐỔIQUYĐỊNHToolStripMenuItem
            // 
            this.tHAYĐỔIQUYĐỊNHToolStripMenuItem.Name = "tHAYĐỔIQUYĐỊNHToolStripMenuItem";
            this.tHAYĐỔIQUYĐỊNHToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.tHAYĐỔIQUYĐỊNHToolStripMenuItem.Text = "THAY ĐỔI QUY ĐỊNH";
            this.tHAYĐỔIQUYĐỊNHToolStripMenuItem.Click += new System.EventHandler(this.tHAYĐỔIQUYĐỊNHToolStripMenuItem_Click);
            // 
            // qUẢNLÝNHÂNVIÊNToolStripMenuItem
            // 
            this.qUẢNLÝNHÂNVIÊNToolStripMenuItem.Name = "qUẢNLÝNHÂNVIÊNToolStripMenuItem";
            this.qUẢNLÝNHÂNVIÊNToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.qUẢNLÝNHÂNVIÊNToolStripMenuItem.Text = "QUẢN LÝ NHÂN VIÊN";
            this.qUẢNLÝNHÂNVIÊNToolStripMenuItem.Click += new System.EventHandler(this.qUẢNLÝNHÂNVIÊNToolStripMenuItem_Click);
            // 
            // qUẢNLÝToolStripMenuItem
            // 
            this.qUẢNLÝToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.đỔIMẬTKHẨUToolStripMenuItem,
            this.đĂNGXUẤTToolStripMenuItem,
            this.tHOÁTToolStripMenuItem});
            this.qUẢNLÝToolStripMenuItem.Name = "qUẢNLÝToolStripMenuItem";
            this.qUẢNLÝToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.qUẢNLÝToolStripMenuItem.Text = "QUẢN LÝ";
            // 
            // đỔIMẬTKHẨUToolStripMenuItem
            // 
            this.đỔIMẬTKHẨUToolStripMenuItem.Name = "đỔIMẬTKHẨUToolStripMenuItem";
            this.đỔIMẬTKHẨUToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.đỔIMẬTKHẨUToolStripMenuItem.Text = "ĐỔI MẬT KHẨU";
            this.đỔIMẬTKHẨUToolStripMenuItem.Click += new System.EventHandler(this.đỔIMẬTKHẨUToolStripMenuItem_Click);
            // 
            // đĂNGXUẤTToolStripMenuItem
            // 
            this.đĂNGXUẤTToolStripMenuItem.Name = "đĂNGXUẤTToolStripMenuItem";
            this.đĂNGXUẤTToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.đĂNGXUẤTToolStripMenuItem.Text = "ĐĂNG XUẤT";
            this.đĂNGXUẤTToolStripMenuItem.Click += new System.EventHandler(this.đĂNGXUẤTToolStripMenuItem_Click);
            // 
            // tHOÁTToolStripMenuItem
            // 
            this.tHOÁTToolStripMenuItem.Name = "tHOÁTToolStripMenuItem";
            this.tHOÁTToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.tHOÁTToolStripMenuItem.Text = "THOÁT";
            this.tHOÁTToolStripMenuItem.Click += new System.EventHandler(this.tHOÁTToolStripMenuItem_Click);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(-1, 28);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(831, 97);
            this.panel1.TabIndex = 33;
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(0, 123);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(831, 412);
            this.panel2.TabIndex = 34;
            // 
            // frmChuongtrinh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(831, 536);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmChuongtrinh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CHƯƠNG TRÌNH QUẢN LÝ NHÀ SÁCH";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmChuongtrinh_FormClosing);
            this.Load += new System.EventHandler(this.frmChuongtrinh_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem gIAODIỆNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dANHMỤCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sÁCHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kHÁCHHÀNGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nGHIỆPVỤToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nHẬPSÁCHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hÓAĐƠNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tHUTIỀNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tHỐNGKÊBÁOCÁOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bÁOCÁOTỒNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bÁOCÁONỢToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cHỨCNĂNGADMINToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tHAYĐỔIQUYĐỊNHToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem qUẢNLÝNHÂNVIÊNToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem qUẢNLÝToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đỔIMẬTKHẨUToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem đĂNGXUẤTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tHOÁTToolStripMenuItem;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;

    }
}