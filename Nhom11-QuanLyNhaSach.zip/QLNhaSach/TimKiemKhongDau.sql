﻿ALTER TABLE Sach ALTER COLUMN TacGia  
            nvarchar(100)COLLATE SQL_Latin1_General_CP1_CI_AI NOT NULL;  
ALTER TABLE Sach ALTER COLUMN TenSach  
            nvarchar(100)COLLATE SQL_Latin1_General_CP1_CI_AI NOT NULL;  
ALTER TABLE KhachHang ALTER COLUMN HoTen  
            nvarchar(100)COLLATE SQL_Latin1_General_CP1_CI_AI NOT NULL;  